// lib/screens/practico_operator_screen.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';

import '../services/database_service.dart';
import '../printing/raw_escpos.dart';
import '../printing/print_config.dart';

class PracticoOperatorScreen extends StatefulWidget {
  const PracticoOperatorScreen({super.key});

  @override
  State<PracticoOperatorScreen> createState() => _PracticoOperatorScreenState();
}

class _PracticoOperatorScreenState extends State<PracticoOperatorScreen> {
  final _rutCtl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  String _nombre = '';
  String _rutOk = '';
  bool _loading = false;

  List<Map<String, dynamic>> _etapas = [];
  bool _hayPendientes = false;

  // Impresora
  List<String> _printers = [];
  String? _printerSel;
  bool _autoPrint = true;

  // Forzar emisión (si hay pendientes)
  bool _forzar = false;

  String _log = '';

  @override
  void initState() {
    super.initState();
    _initUi();
  }

  @override
  void dispose() {
    _rutCtl.dispose();
    super.dispose();
  }

  Future<void> _initUi() async {
    // focus enter para submit
    HardwareKeyboard.instance.addHandler(_handleKey);

    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _printerSel = prefs.getString('printerPractico') ?? PrintConfig.printerNamePractico;
      _autoPrint  = prefs.getBool('autoPrintPractico') ?? true;
    });

    try {
      final list = EscPosRawPrinter.listInstalledPrinters();
      setState(() => _printers = list);
      if (_printerSel == null && list.isNotEmpty) {
        _printerSel = list.first;
      }
    } catch (_) {}
  }

  @override
  void deactivate() {
    HardwareKeyboard.instance.removeHandler(_handleKey);
    super.deactivate();
  }

  bool _handleKey(KeyEvent e) {
    if (e is KeyDownEvent && e.logicalKey == LogicalKeyboardKey.enter) {
      if (!_loading) _consultar();
      return true;
    }
    return false;
  }

  // ─────────────────── Utils RUT (light) ───────────────────
  String _rutClean(String s) =>
      s.toUpperCase().replaceAll(RegExp(r'[^0-9K]'), '');

  bool _rutValido(String raw) {
    final c = _rutClean(raw);
    if (c.length < 2) return false;
    final body = c.substring(0, c.length - 1);
    final dv = c.substring(c.length - 1);
    if (!RegExp(r'^\d{1,8}$').hasMatch(body)) return false;

    int sum = 0, mul = 2;
    for (int i = body.length - 1; i >= 0; i--) {
      sum += int.parse(body[i]) * mul;
      mul = (mul == 7) ? 2 : mul + 1;
    }
    final res = 11 - (sum % 11);
    final dvCalc = (res == 11) ? '0' : (res == 10) ? 'K' : res.toString();
    return dv == dvCalc;
  }

  String _rutFormat(String raw) {
    final c = _rutClean(raw);
    if (c.isEmpty) return '';
    final body = c.substring(0, c.length - 1);
    final dv = c.substring(c.length - 1);
    return '$body-$dv';
  }

  // ─────────────────── Acciones ───────────────────
  Future<void> _consultar() async {
    final r = _rutFormat(_rutCtl.text);
    if (!_rutValido(r) && r != '999-9') {
      _toast('RUT inválido');
      return;
    }
    setState(() {
      _loading = true;
      _etapas = [];
      _hayPendientes = false;
      _nombre = '';
      _rutOk = r;
      _forzar = false;
      _log = '';
    });

    try {
      // 1) Trae etapas (y nombre desde PracticoResult si quieres)
      final etapas = await DatabaseService.instance.etapasPorRut(r);
      final hayPend = etapas.any((e) {
        final id = (e['EtapaId'] as num?)?.toInt() ?? 0;
        final res = (e['Resultado'] ?? '').toString();
        return id <= 885 && (res == 'E' || res == 'S');
      });

      setState(() {
        _etapas = etapas;
        _hayPendientes = hayPend;
        // Nombre si viene en data (algunas consultas traen Nombre)
        final idxNombre = etapas.indexWhere((e) => (e['Nombre'] ?? '').toString().trim().isNotEmpty);
        if (idxNombre >= 0) {
          _nombre = (etapas[idxNombre]['Nombre'] ?? '').toString();
        }
      });

      if (etapas.isEmpty) {
        _appendLog('No se encontraron etapas para $_rutOk');
      } else {
        _appendLog('Etapas cargadas para $_rutOk (${etapas.length})');
      }
    } catch (e) {
      _appendLog('Error al consultar: $e');
      _toast('Error al consultar: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _emitir() async {
    if (_rutOk.isEmpty) {
      _toast('Primero consulta un RUT');
      return;
    }
    if (_hayPendientes && !_forzar) {
      _toast('Tiene etapas pendientes. Activa "Forzar emisión" si corresponde.');
      return;
    }

    setState(() => _loading = true);
    try {
      // Pide correlativo del día y emite
      final res = await DatabaseService.instance.emitirTicketPractico(
        rut: _rutOk,
        nombre: _nombre,
      );

      if (res.success) {
        _appendLog('Ticket emitido: ${res.ticket}');
        if (_autoPrint) {
          await _imprimirTicket(res.ticket ?? 0);
        }
        _dialogOk(
          title: 'Ticket emitido',
          body: 'Número: ${res.ticket ?? 0}',
        );
      } else {
        _appendLog('No se pudo emitir: ${res.message}');
        _toast(res.message ?? 'No se pudo emitir ticket');
      }
    } catch (e) {
      _appendLog('Error al emitir: $e');
      _toast('Error al emitir: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _imprimirTicket(int ticket) async {
    if (ticket <= 0) {
      _toast('Ticket inválido');
      return;
    }
    final name = _nombre;
    final cola = _printerSel ?? PrintConfig.printerNamePractico;

    try {
      final p = EscPosRawPrinter(
        printerName: cola,
        codepage: PrintConfig.codepage,
      );
      await p.printPracticoTicket(
        nombre: name,
        ticket: ticket,
      );
      _appendLog('Impreso en "$cola"');
    } catch (e) {
      _appendLog('Error de impresión: $e');
      _toast('Error de impresión: $e');
    }
  }

  Future<void> _probarImpresora() async {
    final cola = _printerSel ?? PrintConfig.printerNamePractico;
    final err = await EscPosRawPrinter.quickTest(cola);
    if (err == null) {
      _toast('Prueba enviada a "$cola"');
      _appendLog('QuickTest OK en "$cola"');
    } else {
      _toast('QuickTest falló: $err');
      _appendLog('QuickTest ERROR: $err');
    }
  }

  void _appendLog(String s) {
    setState(() => _log = (_log.isEmpty ? s : '$_log\n$s'));
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _dialogOk({required String title, required String body}) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _savePrinterSel(String? v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('printerPractico', v ?? '');
  }

  Future<void> _saveAutoPrint(bool v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('autoPrintPractico', v);
  }

  // ─────────────────── UI ───────────────────
  Widget _etapaRow(Map e) {
    final id = (e['EtapaId'] as num?)?.toInt() ?? 0;
    final res = (e['Resultado'] ?? '').toString();
    final pend = id <= 885 && (res == 'E' || res == 'S');
    final name = switch (id) {
      880 => 'CAJA',
      881 => 'FOTOGRAFÍA',
      882 => 'EXAMEN PSICOMÉTRICO',
      883 => 'EXAMEN SENSOMÉTRICO',
      884 => 'ENTREVISTA MÉDICA',
      885 => 'EXAMEN TEÓRICO',
      _   => 'ETAPA $id',
    };
    return ListTile(
      dense: true,
      leading: Icon(pend ? Icons.close_rounded : Icons.check_circle_rounded,
          color: pend ? Colors.red : Colors.green),
      title: Text('$id  $name', style: const TextStyle(fontWeight: FontWeight.w700)),
      trailing: Text(res.isEmpty ? '-' : res,
          style: TextStyle(
            color: pend ? Colors.red : Colors.green,
            fontWeight: FontWeight.bold,
          )),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Operador · Examen Práctico'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // RUT + acciones
              Form(
                key: _formKey,
                child: Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _rutCtl,
                        decoration: const InputDecoration(
                          labelText: 'RUT',
                          hintText: 'Ej: 20936873-0',
                          border: OutlineInputBorder(),
                        ),
                        textInputAction: TextInputAction.search,
                        onFieldSubmitted: (_) => _consultar(),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9kK-]')),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    FilledButton.icon(
                      onPressed: _loading ? null : _consultar,
                      icon: _loading
                          ? const SizedBox(
                              width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.search),
                      label: const Text('Consultar'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              // Impresora + auto print + forzar
              Row(
                children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _printers.contains(_printerSel) ? _printerSel : null,
                      items: _printers.map((p) => DropdownMenuItem(value: p, child: Text(p))).toList(),
                      onChanged: (v) async {
                        setState(() => _printerSel = v);
                        await _savePrinterSel(v);
                      },
                      decoration: const InputDecoration(
                        labelText: 'Impresora práctica',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton.icon(
                    onPressed: _probarImpresora,
                    icon: const Icon(Icons.print),
                    label: const Text('Probar'),
                  ),
                  const SizedBox(width: 8),
                  Row(
                    children: [
                      const Text('Auto imprimir'),
                      Switch(
                        value: _autoPrint,
                        onChanged: (v) async {
                          setState(() => _autoPrint = v);
                          await _saveAutoPrint(v);
                        },
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 10),

              // Nombre + Forzar
              Row(
                children: [
                  Expanded(
                    child: Text(
                      _nombre.isEmpty ? '—' : _nombre,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                  ),
                  Tooltip(
                    message: 'Permite emitir ticket aunque existan etapas pendientes',
                    child: Row(
                      children: [
                        const Text('Forzar emisión'),
                        Checkbox(
                          value: _forzar,
                          onChanged: (v) => setState(() => _forzar = v ?? false),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    onPressed: _loading ? null : _emitir,
                    icon: const Icon(Icons.confirmation_number_outlined),
                    label: const Text('Emitir ticket'),
                  ),
                ],
              ),

              const SizedBox(height: 8),

              // Etapas
              Expanded(
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    side: BorderSide(color: cs.outlineVariant),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: _etapas.isEmpty
                      ? const Center(child: Text('Sin etapas cargadas'))
                      : ListView.builder(
                          itemCount: _etapas.length,
                          itemBuilder: (_, i) => _etapaRow(_etapas[i]),
                        ),
                ),
              ),

              // Log
              SizedBox(
                height: 120,
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    side: BorderSide(color: cs.outlineVariant),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: SingleChildScrollView(
                      child: Text(
                        _log.isEmpty ? 'Log...' : _log,
                        style: const TextStyle(fontFamily: 'Consolas', fontSize: 12),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
