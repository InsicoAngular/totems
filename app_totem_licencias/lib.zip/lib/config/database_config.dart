// lib/config/database_config.dart
import 'dart:convert';

class DatabaseConfig {
  // ——— Parámetros de conexión SQL ———
  static const ip     = String.fromEnvironment('DB_IP');
  static const port   = String.fromEnvironment('DB_PORT');
  static const dbName = String.fromEnvironment('DB_NAME');
  static const user   = String.fromEnvironment('DB_USER');
  static const pass   = String.fromEnvironment('DB_PASS');
  // config/database_config.dart
static const Map<String,String> labelsByTipo = {
  'P': 'Boton Primera Licencia',
  'R': 'Boton Renovacion Licencia',
  'D': 'Boton Duplicado',            // ajusta al nombre real si difiere
  'C': 'Boton Cambio Domicilio',
  'T': 'Boton Examenes Practicos',
};

static String labelByTipo(String tipo) =>
    labelsByTipo[tipo.toUpperCase()] ?? tipo;

  // ——— Endpoints REST ———
  static const endpoint = String.fromEnvironment('DB_ENDPOINT'); // online
  static const apiBase  = String.fromEnvironment('apiBase');     // manual

  // ——— Flags ———
  // ✅ Léelo como bool real:
  static const bool practico =
      bool.fromEnvironment('DB_PRACTICO', defaultValue: false);
      
  static const bool mockManual =
      bool.fromEnvironment('DB_MOCK_MANUAL', defaultValue: false);

  // ——— Totem / perfil ———
  static const totemId =
      int.fromEnvironment('TOTEM_ID', defaultValue: 0);

  // ——— Tipo por defecto (para no mapeados) ———
  static const defaultTipo =
      String.fromEnvironment('DB_DEFAULT_TIPO', defaultValue: 'T');

  // ====== Normalización interna (para lookups robustos) ======
  static String _normalize(String s) {
    var out = s.toLowerCase().trim();
    const f = 'áéíóúñ', t = 'aeioun';
    for (var i = 0; i < f.length; i++) out = out.replaceAll(f[i], t[i]);
    return out;
  }

  // Guardamos el JSON crudo para recuperar las etiquetas "bonitas" del UI
  static final String _tramiteMapRaw =
      const String.fromEnvironment('TRAMITE_MAP', defaultValue: '{}');

  // Mapa normalizado para lookups: "primera licencia" → "P"
  static final Map<String, String> tramiteMap = (() {
    final dec = (jsonDecode(_tramiteMapRaw) as Map<String, dynamic>);
    final map = <String, String>{};
    dec.forEach((k, v) => map[_normalize(k.toString())] = v.toString());
    return map;
  })();

  // Etiquetas para UI (tal como vinieron en el JSON, con mayúsculas/acentos)
  static final List<String> tramiteLabels = (() {
    final dec = (jsonDecode(_tramiteMapRaw) as Map<String, dynamic>);
    return dec.keys.map((k) => k.toString()).toList();
  })();

  // Obtiene el tipo desde una etiqueta cualquiera (botón o clase2)
  static String tipoByLabel(String label) {
    return tramiteMap[_normalize(label)] ?? defaultTipo;
  }
}
