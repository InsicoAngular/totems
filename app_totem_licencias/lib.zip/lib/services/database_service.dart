// lib/services/database_service.dart
import 'dart:async';
import 'dart:convert';
import 'dart:convert' show latin1;

import 'package:app_totem_licencias/models/atencion.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mssql_connection/mssql_connection.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config/database_config.dart';
import '../models/insert_result.dart';
import '../models/practico_result.dart';
import '../models/reserva.dart';

/// ───────── Verificación de cupos manuales (TOP-LEVEL) ─────────
class CupoCheck {
  final bool ok;
  final int? cupoId;
  final int disponibles;
  final String motivo;

  // Horario y flag “dentro de rango”
  final String horaInicio;   // "08:30:00"
  final String horaTermino;  // "17:04:00"
  final bool dentroHorario;

  const CupoCheck({
    required this.ok,
    this.cupoId,
    required this.disponibles,
    required this.motivo,
    required this.horaInicio,
    required this.horaTermino,
    required this.dentroHorario,
  });
}

// Modelo simple para el flujo de práctico (si lo usas en UI)
class PracticoFlowResult {
  final bool ok;
  final int? ticket;
  final String? nombre;
  final List<Map<String, dynamic>> etapas;
  final String? message;

  PracticoFlowResult({
    required this.ok,
    this.ticket,
    this.nombre,
    this.etapas = const [],
    this.message,
  });
}

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  /* ───────── conexión ───────── */
  final _conn = MssqlConnection.getInstance();
  bool _initialized = false;

  final _ip       = DatabaseConfig.ip;
  final _port     = DatabaseConfig.port;
  final _db       = DatabaseConfig.dbName;
  final _usr      = DatabaseConfig.user;
  final _pwd      = DatabaseConfig.pass;
  final _endpoint = DatabaseConfig.endpoint;
  final _totemId  = DatabaseConfig.totemId;

  // ───────── helpers extra ─────────
  String _onlyDigits(String s) => s.replaceAll(RegExp(r'\D'), '');
  bool   get _isPractico => DatabaseConfig.practico;
  int?   _profileId;

  /* ───────── helpers ───────── */
  // ⚠️ Usar _toAnsi solo si realmente necesitas ANSI.
  String _toAnsi(String t) => String.fromCharCodes(latin1.encode(t));

  String _normalize(String s) {
    var out = s.toLowerCase().trim();
    const f = 'áéíóúñ', t = 'aeioun';
    for (var i = 0; i < f.length; i++) {
      out = out.replaceAll(f[i], t[i]);
    }
    return out;
  }

  /* ───────── conexión + perfil ───────── */
  Future<void> _ensureConnection() async {
    if (_initialized) return;

    final ok = await _conn.connect(
      ip: _ip,
      port: _port,
      databaseName: _db,
      username: _usr,
      password: _pwd,
      timeoutInSeconds: 15,
    );
    if (!ok) throw Exception('No se pudo conectar a SQL Server');

    final js = await _conn
        .getData('SELECT PerfilId FROM TO_Totems WHERE TotemId=$_totemId');
    final rows = jsonDecode(js) as List;
    if (rows.isEmpty) {
      throw Exception('TotemId $_totemId no existe en la BD');
    }
    _profileId = rows.first['PerfilId'] as int;
    _initialized = true;
  }

  /* ───────── config remota ───────── */
  Future<String?> fetchConfigJson() async {
    await _ensureConnection();
    if (_totemId == 0) return null;

    final js = await _conn
        .getData('SELECT ConfigJson FROM TO_TotemConfig WHERE TotemId=$_totemId');
    final rows = jsonDecode(js) as List;
    return rows.isEmpty ? null : rows.first['ConfigJson'] as String;
  }

  /* ────────── FETCH RESERVA / PRÁCTICO ────────── */
  Future<dynamic /* Reserva? | PracticoResult? */ > fetchReserva(String rut) async {
    await _ensureConnection();
    switch (_profileId) {
      case 1:
        return _isPractico ? _fetchEstadoPractico(rut) : _fetchReservaLicencias(rut);
      default:
        throw UnsupportedError('Perfil $_profileId aún no implementado');
    }
  }

  /*──────────────────── LICENCIAS · lee reserva del endpoint ───────────────────*/
  Future<Reserva?> _fetchReservaLicencias(String rut) async {
    debugPrint('[LICENCIAS] llamando API para $rut');

    final url  = '$_endpoint/api/conector/v1/reservaTOTEM/$rut';
    final resp = await http.get(Uri.parse(url));

    debugPrint('[LICENCIAS] HTTP ${resp.statusCode}');
    if (resp.statusCode != 200) return null;

    final body = jsonDecode(resp.body) as Map<String, dynamic>;
    debugPrint('[LICENCIAS] body: $body');

    if (body['success'] != true) {
      debugPrint('[LICENCIAS] body["success"] != true');
      return null;
    }

    final data = body['data'] as List;
    debugPrint('[LICENCIAS] data.length = ${data.length}');
    if (data.isEmpty) return null;

    final reserva = Reserva.fromJson(Map<String, dynamic>.from(data.first));
    debugPrint('[LICENCIAS] Reserva OK fecha=${reserva.fechaCitacion} hora=${reserva.horaCitacion}');
    return reserva;
  }

  Future<PracticoResult?> _fetchEstadoPractico(String rut) async {
    final cleaned = rut.replaceAll('.', '').trim();
    final parts = cleaned.split('-');
    if (parts.length != 2) return null;

    final numero = int.tryParse(parts[0]) ?? 0;
    final digito = parts[1];

    final sql = '''
      SELECT TOP 1
        pa.PAPersonaId,
        pa.RutNumero,
        pa.RutDigito,
        CONCAT(pa.Nombres,' ',pa.ApellidoPaterno,' ',pa.ApellidoMaterno) AS nombre,
        af.FechaResultado,
        ae.ALCParametro_General_Etapa_id,
        af.ALCEstado_id,
        af.Resultado
      FROM PAPersona pa
      JOIN ALCMaestro            am ON pa.PAPersonaId = am.PAPersonaId
      JOIN ALCEstados            ae ON am.id          = ae.ALCMaestro_id
      JOIN ALCEstados_Flujos     af ON ae.id         = af.ALCEstado_id
      WHERE pa.RutNumero = $numero AND pa.RutDigito = '$digito'
      ORDER BY af.FechaCreacion DESC;
    ''';

    final js = await _conn.getData(sql);
    final rows = jsonDecode(js) as List;
    return rows.isEmpty ? null : PracticoResult.fromJson(Map<String, dynamic>.from(rows.first));
  }

  /*──────── MAIN fetchAndInsert ───────*/
  Future<InsertResult> fetchAndInsert(String rut, String code) async {
    await _ensureConnection();

    // 0) Práctico (perfil de práctico): flujo propio
    if (_isPractico) {
      return _fetchAndInsertPractico(rut);
    }

    // 1) ONLINE: reserva web → inserta en ALCAtenciones
    if (code == 'ON') {
      final reserva = await _fetchReservaLicencias(rut);
      if (reserva == null) {
        return InsertResult(success: false, message: 'No se encontró reserva activa');
      }

      // Tolerancia fecha/hora (mismo día y no excedida)
      try {
        final y = int.parse(reserva.fechaCitacion.substring(0, 4));
        final m = int.parse(reserva.fechaCitacion.substring(4, 6));
        final d = int.parse(reserva.fechaCitacion.substring(6, 8));
        final parts = reserva.horaCitacion.split(':').map(int.parse).toList();
        final cita = DateTime(y, m, d, parts[0], parts[1], parts[2]);
        final now  = DateTime.now();
        final esMismoDia = now.year == y && now.month == m && now.day == d;
        if (!esMismoDia && now.isAfter(cita)) {
          return InsertResult(success: false, message: 'Se ha excedido la hora acordada');
        }
      } catch (_) {}

      // Inserción (si duplica, se reutiliza)
      return _insertAtencionLicencias(reserva);
    }

    // 2) Manual/ALC: si la UI manual necesita insertar correlativo diario,
    //    usa insertarAtencionTipoDia(...) directamente.
    //    Si solo se quiere “confirmar” una ya existente → registrarDesdeALC(...)
    return registrarDesdeALC(rut: rut, tipo: code);
  }

  /* ─────────────── LICENCIAS - INSERT EN ALCATENCIONES ─────────────── */
  Future<InsertResult> _insertAtencionLicencias(Reserva r) async {
    await _ensureConnection();

    try {
      // Siguiente número de solicitud para este RUT+CORRELATIVO
      final numJs = await _conn.getData("""
        SELECT MAX(TRY_CAST(L28_NUMSOL AS INT)) AS max_sol,
               SUM(CASE WHEN L28_NUMSOL IS NULL OR L28_NUMSOL='' THEN 1 ELSE 0 END) AS nulls
        FROM ALCAtenciones
        WHERE L28_NUMRUT='${_onlyDigits(r.numRut)}'
          AND L28_CORRELATIVO='${r.correlativo}';
      """);

      final rows   = jsonDecode(numJs) as List;
      final row    = rows.isEmpty ? <String, dynamic>{} : rows.first as Map<String, dynamic>;
      final maxSol = (row['max_sol'] ?? 0) as int;
      final nulls  = (row['nulls']  ?? 0) as int;
      final nextNumSol = (maxSol + nulls + 1).toString();

      final claseNorm = _normalize(r.clase2);
      final tipo      = DatabaseConfig.tramiteMap[claseNorm] ?? 'P';

      final now = DateTime.now();
      final horaNow = '${now.hour.toString().padLeft(2,'0')}${now.minute.toString().padLeft(2,'0')}${now.second.toString().padLeft(2,'0')}';

      // ⚠️ Importante: NO convertir a ANSI; usar NVARCHAR (N'...')
final nombresSql   = _toVarcharSafe(r.nombres);
final apellidosSql = _toVarcharSafe(r.apellidos);

final sql = """
  INSERT INTO ALCAtenciones (
    L28_FECHA, L28_TIPO, L28_CORRELATIVO, L28_NUMRUT,
    L28_HORA, L28_ATENDIDO, L28_ASIGNADO,
    L28_NOMBRES, L28_APELLIDOS, L28_NUMSOL
  ) VALUES (
    '${r.fechaCitacion}', '$tipo', '${r.correlativo}', '${_onlyDigits(r.numRut)}',
    '$horaNow', 'N', 'N',
    '$nombresSql', '$apellidosSql', '$nextNumSol'
  );
""";


      await _conn.writeData(sql);

      return InsertResult(
        success: true,
        ticket: int.tryParse(nextNumSol) ?? 0,
        message: 'Registro exitoso en ALCAtenciones',
      );
    } catch (e) {
      final msg = e.toString();

      // Clave duplicada → ya existe fila (la reutilizamos)
      final isDup = msg.contains('2627') || msg.contains('IX_ALCAtenciones');
      if (isDup) {
        final claseNorm = _normalize(r.clase2);
        final tipo      = DatabaseConfig.tramiteMap[claseNorm] ?? 'P';

        final js = await _conn.getData("""
          SELECT TOP 1 id, L28_NUMSOL
          FROM ALCAtenciones
          WHERE L28_FECHA='${r.fechaCitacion}'
            AND L28_TIPO='$tipo'
            AND L28_CORRELATIVO='${r.correlativo}'
          ORDER BY id DESC;
        """);

        final rows = List<Map<String, dynamic>>.from(jsonDecode(js));
        if (rows.isNotEmpty) {
          final numSol = (rows.first['L28_NUMSOL'] as String?) ?? '';
          final tk = int.tryParse(numSol) ?? (rows.first['id'] as num?)?.toInt() ?? 0;

          return InsertResult(
            success: true,
            ticket: tk,
            message: 'Registro ya existía; reutilizado',
          );
        }
      }

      return InsertResult(success: false, message: 'Error BD: $e');
    }
  }

  /* ─────────────── PRÁCTICO ─────────────── */
  Future<List<Map<String, dynamic>>> _fetchEtapas(int estadoId) async {
    final js = await _conn.getData("""
      SELECT
        pa.RutNumero,
        pa.RutDigito,
        CONCAT(pa.Nombres, ' ', pa.ApellidoPaterno, ' ', pa.ApellidoMaterno) AS Nombre,
        af.ALCParametros_General_Etapa_id AS EtapaId,
        af.Resultado,
        CASE WHEN af.Resultado IN ('E','S') THEN 1 ELSE 0 END AS Pendiente
      FROM PAPersona             pa
      JOIN ALCMaestro            al ON pa.PAPersonaId = al.PAPersonaId
      JOIN ALCEstados            ae ON al.id          = ae.ALCMaestro_id
      JOIN ALCEstados_Flujos     af ON ae.id         = af.ALCEstado_id
      WHERE af.ALCEstado_id = $estadoId
        AND af.ALCParametros_General_Etapa_id BETWEEN 880 AND 889
      ORDER BY af.ALCParametros_General_Etapa_id;
    """);

    final rows = List<Map<String, dynamic>>.from(jsonDecode(js));

    debugPrint('[DB] Etapas recibidas (estadoId=$estadoId):');
    for (final r in rows) {
      debugPrint('  id=${r['EtapaId']} res=${r['Resultado']} pend=${r['Pendiente']}');
    }

    return rows;
  }

/// Práctico → ahora SIEMPRE valida etapas antes de insertar.
/// (Antes se saltaba la validación.)
Future<InsertResult> registrarPracticoEnALCAtenciones(
  String rut, {
  String nombres = '',
  String apellidos = '',
}) async {
  // Delegamos al flujo con validación (_fetchAndInsertPractico)
  return _fetchAndInsertPractico(rut);
}

  Future<InsertResult> _fetchAndInsertPractico(String rut) async {
    final res = await _fetchEstadoPractico(rut);
    if (res == null) return InsertResult(success: false);

    final etapas = await _fetchEtapas(res.estadoId);
    final pendiente = etapas.any((e) =>
        e['EtapaId'] <= 885 && (e['Resultado'] == 'E' || e['Resultado'] == 'S'));

    if (pendiente) {
      // No inserta; devolvemos etapas para la UI
      return InsertResult(success: false, extra: etapas);
    }

    // Todas aprobadas → obtener correlativo del día en ALCAtenciones via SP
    final ins = await insertarAtencionTipoDia(
      rut: rut,
      tipo: 'Z',
      nombres: res.nombre, // puedes partirlo si quieres; así ya imprime bien
      apellidos: '',
    );

    return ins;
  }

  /* ─────────── refresco local config ─────────── */
  Future<bool> refreshLocalConfig() async {
    final raw = await fetchConfigJson();
    if (raw == null) return false;

    late final Map<String, dynamic> cfg;
    try {
      cfg = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return false;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs
      ..setString('welcomeText', cfg['welcomeText'] ?? '')
      ..setString('hashtag',     cfg['hashtag']     ?? '')
      ..setString('marqueeText', cfg['marqueeText'] ?? '')
      ..setInt   ('buttonBg',    cfg['buttonBg'] ?? Colors.deepPurple.value)
      ..setInt   ('buttonText',  cfg['buttonText'] ?? Colors.white.value)
      ..setString('assetsDir',   cfg['assetsDir']  ?? r'C:\Insico\assets\');
    return true;
  }

  /// Consume cupo manual del día y retorna el correlativo asignado.
  Future<InsertResult> consumirManual() async {
    await _ensureConnection();

    final sql = """
DECLARE @c int, @m nvarchar(200), @rc int;
EXEC @rc = dbo.sp_TO_Manual_Consume
          @TotemId=$_totemId,
          @Correlativo=@c OUTPUT,
          @Msg=@m OUTPUT;
SELECT rc=@rc, correlativo=@c, msg=@m;
""";

    final rows = List<Map<String, dynamic>>.from(jsonDecode(await _conn.getData(sql)));
    if (rows.isEmpty) {
      return InsertResult(success: false, message: 'Sin respuesta del servidor');
    }
    final r = rows.first;
    final ok  = (r['rc'] as int?) == 0;
    final num = (r['correlativo'] as int?) ?? 0;
    final msg = (r['msg'] as String?) ?? (ok ? 'OK' : 'Error');

    return InsertResult(success: ok, ticket: num, message: msg);
  }

  /* ───────── ALC (lectura/confirmación) ───────── */
  Future<Atencion?> _fetchAtencionALC(String rut, String tipo) async {
    await _ensureConnection();

    final rutSolo = _onlyDigits(rut);
    final tipoAnsi = _toAnsi(tipo).replaceAll("'", "''");

    final sql = """
DECLARE @FECHA CHAR(8) = CONVERT(CHAR(8), GETDATE(), 112);
;WITH CANDIDATOS AS (
    -- 1) Mismo RUT + mismo TIPO + ASIGNADO='S'
    SELECT a.*, 1 AS prio
      FROM ALCAtenciones a
     WHERE a.L28_FECHA = @FECHA
       AND a.L28_NUMRUT = '$rutSolo'
       AND a.L28_TIPO   = '$tipoAnsi'
       AND (a.L28_ATENDIDO IS NULL OR a.L28_ATENDIDO='N')
       AND a.L28_ASIGNADO='S'

    UNION ALL
    -- 2) Mismo RUT + mismo TIPO (última no atendida)
    SELECT a.*, 2 AS prio
      FROM ALCAtenciones a
     WHERE a.L28_FECHA = @FECHA
       AND a.L28_NUMRUT = '$rutSolo'
       AND a.L28_TIPO   = '$tipoAnsi'
       AND (a.L28_ATENDIDO IS NULL OR a.L28_ATENDIDO='N')

    UNION ALL
    -- 3) Mismo RUT (cualquier TIPO) + ASIGNADO='S'
    SELECT a.*, 3 AS prio
      FROM ALCAtenciones a
     WHERE a.L28_FECHA = @FECHA
       AND a.L28_NUMRUT = '$rutSolo'
       AND (a.L28_ATENDIDO IS NULL OR a.L28_ATENDIDO='N')
       AND a.L28_ASIGNADO='S'

    UNION ALL
    -- 4) Mismo RUT (cualquier TIPO) última no atendida
    SELECT a.*, 4 AS prio
      FROM ALCAtenciones a
     WHERE a.L28_FECHA = @FECHA
       AND a.L28_NUMRUT = '$rutSolo'
       AND (a.L28_ATENDIDO IS NULL OR a.L28_ATENDIDO='N')
)
SELECT TOP 1 *
  FROM CANDIDATOS
 ORDER BY prio ASC, id DESC;
""";

    final js = await _conn.getData(sql);
    final rows = List<Map<String, dynamic>>.from(jsonDecode(js));
    if (rows.isEmpty) return null;
    return Atencion.fromJson(rows.first);
  }

  // Marca "impreso/tocado" sin cerrar la fila (NO pone ATENDIDO='S')
  Future<bool> _touchALC(int id) async {
    await _ensureConnection();

    final now = DateTime.now();
    final fecha = '${now.year.toString().padLeft(4,'0')}${now.month.toString().padLeft(2,'0')}${now.day.toString().padLeft(2,'0')}';
    final hora  = '${now.hour.toString().padLeft(2,'0')}${now.minute.toString().padLeft(2,'0')}${now.second.toString().padLeft(2,'0')}';

    final sql = """
UPDATE ALCAtenciones
   SET L28_HORA      = ISNULL(L28_HORA, '$hora'),
       intentos      = ISNULL(intentos,0) + 1,
       L28_USUARIO_MOD='TOTEM',
       L28_FECHA_MOD='$fecha',
       L28_HORA_MOD ='$hora'
 WHERE id=$id;
""";

    try {
      await _conn.writeData(sql);
      return true;
    } catch (_) {
      return false;
    }
  }

  int _asInt(String? s) => int.tryParse((s ?? '').trim()) ?? 0;

int _bestTicketFromAtencion(Atencion a) {
  final c1 = _asInt(a.correlativo1); // si lo usas en tu BD
  if (c1 > 0) return c1;
  final c0 = _asInt(a.correlativo);  // L28_CORRELATIVO
  if (c0 > 0) return c0;
  final sol = _asInt(a.numSol);      // por si usas N° solicitud
  if (sol > 0) return sol;
  return a.id;                       // último fallback
}

  Future<InsertResult> registrarDesdeALC({
    required String rut,
    required String tipo, 
  }) async {
    await _ensureConnection();

    final a = await _fetchAtencionALC(rut, tipo);
    if (a == null) {
      return InsertResult(success: false, message: 'No hay atención registrada para hoy con ese trámite');
    }

    final ok = await _touchALC(a.id);

final ticketOk = _bestTicketFromAtencion(a); // ⬅️ acá elija correlativo
return InsertResult(
  success: ok,
  ticket: ticketOk,
  message: ok ? 'Atención confirmada, imprimiendo voucher' : 'No se pudo confirmar la atención',
  extra: {
    'id': a.id,
    'fecha': a.fecha,
    'tipo': a.tipo,
    'numRut': a.numRut,
    'nombres': a.nombres ?? '',
    'apellidos': a.apellidos ?? '',
    'numSol': a.numSol ?? '',
    'correlativo': a.correlativo,
    'correlativo1': a.correlativo1 ?? '',
  },
);

  }

  /* ───────── Cupos / Botones manuales ───────── */
Future<CupoCheck> checkCupoManualPorLabel({
  required String labelTramite,
  bool requiereApertura = true,
}) async {
  await _ensureConnection();

  final lbl = _toAnsi(labelTramite).replaceAll("'", "''");

  final sql = """
;WITH bloques AS (
  SELECT
    id,
    tramite,
    horaInicio,
    horaTermino,
    cantidad,
    CAST(CASE WHEN ISNULL(activo,0)=1 THEN 1 ELSE 0 END AS bit) AS activo,
    ISNULL(cuposUsados, 0) AS cuposUsados,
    jornada,
    CASE
      WHEN CONVERT(time, GETDATE()) BETWEEN horaInicio AND horaTermino THEN 0  -- en curso
      WHEN horaInicio > CONVERT(time, GETDATE())                               THEN 1  -- próximo
      ELSE 2                                                                    -- terminó
    END AS rankSel,
    CASE
      WHEN CONVERT(time, GETDATE()) BETWEEN horaInicio AND horaTermino THEN 1
      ELSE 0
    END AS dentroHorario
  FROM ALCBotonesTotem WITH (READPAST)
  WHERE tramite COLLATE SQL_Latin1_General_CP1_CI_AI
        = N'$lbl' COLLATE SQL_Latin1_General_CP1_CI_AI
        AND ISNULL(activo,0) = 1
)


SELECT TOP 1
  id,
  tramite,
  CONVERT(varchar(8), horaInicio, 108)  AS horaInicio,
  CONVERT(varchar(8), horaTermino, 108) AS horaTermino,
  cantidad,
  activo,
  cuposUsados,
  jornada,
  dentroHorario,
  (cantidad - cuposUsados) AS stock
FROM bloques
ORDER BY
  rankSel ASC,                                            -- 0: en curso, 1: próximo, 2: terminó
  CASE WHEN rankSel = 0 AND jornada = 'T' THEN 0 ELSE 1 END ASC,  -- si ambos en curso: Tarde antes que Día
  CASE WHEN rankSel = 0 THEN horaInicio END DESC,         -- en curso: la que empezó más tarde
  CASE WHEN rankSel = 1 THEN horaInicio END ASC,          -- próximo: la que empieza antes
  horaInicio DESC,                                        -- resto: estable
  id DESC;
""";

  final rows = List<Map<String, dynamic>>.from(jsonDecode(await _conn.getData(sql)));

  if (rows.isEmpty) {
    return const CupoCheck(
      ok: false,
      cupoId: null,
      disponibles: 0,
      motivo: 'No se han habilitado cupos para este trámite',
      horaInicio: '00:00:00',
      horaTermino: '00:00:00',
      dentroHorario: false,
    );
  }

  final r      = rows.first;
  final id     = (r['id'] as num).toInt();
  final stock  = (r['stock'] as num).toInt();
  final usados = (r['cuposUsados'] as num).toInt();
  final dentro = (r['dentroHorario'] as num).toInt() == 1;
  final hIni   = r['horaInicio'].toString();
  final hFin   = r['horaTermino'].toString();

  final abiertos = !requiereApertura || usados >= 1;

  if (!abiertos) {
    return CupoCheck(
      ok: false,
      cupoId: id,
      disponibles: stock,
      motivo: 'No se han habilitado cupos para este trámite',
      horaInicio: hIni,
      horaTermino: hFin,
      dentroHorario: dentro,
    );
  }
  if (!dentro) {
    return CupoCheck(
      ok: false,
      cupoId: id,
      disponibles: stock,
      motivo: 'Fuera de horario',
      horaInicio: hIni,
      horaTermino: hFin,
      dentroHorario: dentro,
    );
  }
  if (stock <= 0) {
    return CupoCheck(
      ok: false,
      cupoId: id,
      disponibles: 0,
      motivo: 'Cupos agotados por hoy',
      horaInicio: hIni,
      horaTermino: hFin,
      dentroHorario: dentro,
    );
  }

  return CupoCheck(
    ok: true,
    cupoId: id,
    disponibles: stock,
    motivo: 'OK',
    horaInicio: hIni,
    horaTermino: hFin,
    dentroHorario: dentro,
  );
}

  Future<int> ensurePracticoTicket({
    required String rut,
    String? nombres,
    String? apellidos,
  }) async {
    final res = await insertarAtencionTipoDia(
      rut: rut,
      tipo: 'Z', // correlativo diario para práctico
      nombres: nombres ?? '',
      apellidos: apellidos ?? '',
    );
    return res.ticket ?? 0;
  }

Future<InsertResult> insertarAtencionTipoDia({
  required String rut,
  String tipo = 'Z',
  String nombres = '',
  String apellidos = '',
  String usuario = 'TOTEM',
  String ipLocal = '0.0.0.0',
}) async {
  await _ensureConnection();

  final rutSolo       = _onlyDigits(rut);
  final nombresSql    = _toVarcharSafe(nombres);
  final apellidosSql  = _toVarcharSafe(apellidos);
  final tipoSql       = _toVarcharSafe(tipo);
  final usuarioSql    = _toVarcharSafe(usuario);
  final ipSql         = _toVarcharSafe(ipLocal);

  final sql = """
EXEC dbo.sp_ALC_InsertAtencion_TipoDia
  @NumRut     = '$rutSolo',
  @Tipo       = '$tipoSql',
  @Nombres    = '$nombresSql',
  @Apellidos  = '$apellidosSql',
  @UsuarioMod = '$usuarioSql',
  @IPLocal    = '$ipSql';
""";

  final js = await _conn.getData(sql);
  final rows = List<Map<String, dynamic>>.from(jsonDecode(js));
  if (rows.isEmpty) {
    return InsertResult(success: false, message: 'Sin respuesta del SP');
  }
  final r      = rows.first;
  final ticket = (r['Ticket'] as num?)?.toInt() ?? 0;
  final id     = (r['IdAtencion'] as num?)?.toInt() ?? 0;

  return InsertResult(
    success: ticket > 0,
    ticket: ticket,
    message: ticket > 0 ? 'Atención registrada' : 'No se pudo generar correlativo',
    extra: {'id': id, 'Fecha': r['Fecha'], 'Tipo': r['Tipo']},
  );
}


  // Helpers RUT: separa cuerpo y dígito
  Map<String, dynamic> _splitRut(String rut) {
    final clean = rut.replaceAll('.', '').replaceAll('-', '');
    if (clean.length < 2) return {'num': 0, 'dv': ''};
    final dv = clean.substring(clean.length - 1);
    final num = int.tryParse(clean.substring(0, clean.length - 1)) ?? 0;
    return {'num': num, 'dv': dv};
  }

  // Busca persona en PAPersona
  Future<Map<String, String>?> _buscarPersonaPorRut(String rut) async {
    await _ensureConnection();
    final s = _splitRut(rut);
    final num = s['num'] as int;
    final dv  = s['dv'] as String;
    if (num == 0 || dv.isEmpty) return null;

    final js = await _conn.getData("""
    SELECT TOP 1
      Nombres,
      ApellidoPaterno,
      ApellidoMaterno
    FROM PAPersona
    WHERE RutNumero = $num AND RutDigito = '$dv';
  """);

    final rows = List<Map<String, dynamic>>.from(jsonDecode(js));
    if (rows.isEmpty) return null;

    final r   = rows.first;
    final nom = (r['Nombres'] ?? '').toString().trim();
    final ap  = (r['ApellidoPaterno'] ?? '').toString().trim();
    final am  = (r['ApellidoMaterno'] ?? '').toString().trim();
    final ape = [ap, am].where((x) => x.isNotEmpty).join(' ');
    return {'nombres': nom, 'apellidos': ape};
  }

  /// Inserta MANUAL "espontáneo":
  /// - Si hay persona en PAPersona → inserta con su nombre.
  /// - Si no hay persona → inserta vacío, toma el ticket y
  ///   actualiza esa fila para dejar L28_NOMBRES = 'Nº <ticket>'.
  Future<InsertResult> insertarManualEspontaneo({
    required String rut,
    required String tipo,      // ej: 'P','R','D','E','C','Z'...
    String usuario = 'TOTEM',
    String ipLocal = '0.0.0.0',
  }) async {
    await _ensureConnection();

    // 1) Buscamos datos en PAPersona
    final per = await _buscarPersonaPorRut(rut);

    if (per != null) {
      // 2) Existe → insertar con nombre/apellidos (Unicode)
      return insertarAtencionTipoDia(
        rut: rut,
        tipo: tipo,
        nombres: per['nombres'] ?? '',
        apellidos: per['apellidos'] ?? '',
        usuario: usuario,
        ipLocal: ipLocal,
      );
    }

    // 3) No existe → insertar vacío para obtener ticket/id
    final ins = await insertarAtencionTipoDia(
      rut: rut,
      tipo: tipo,
      nombres: '',
      apellidos: '',
      usuario: usuario,
      ipLocal: ipLocal,
    );

    if (!ins.success) return ins;

    // 4) Poner "Nº <ticket>" como nombre para que el llamado lo use
    final id     = (ins.extra?['id'] as num?)?.toInt() ?? 0;
    final ticket = ins.ticket ?? 0;

if (id > 0 && ticket > 0) {
  // evita 'º' para que no termine en '?'
  final nombreFallback = _toVarcharSafe("Nro. $ticket");
  try {
    await _conn.writeData("""
      UPDATE ALCAtenciones
         SET L28_NOMBRES = '$nombreFallback',
             L28_APELLIDOS = ''
       WHERE id = $id
         AND (L28_NOMBRES IS NULL OR L28_NOMBRES = '');
    """);
  } catch (_) {}
}

    return ins;
  }

  /// “Smart” para el botón MANUAL:
  /// - Si ya hay atención hoy (misma lógica de _fetchAtencionALC) → _touch y reimprime.
  /// - Si no hay → crea correlativo espontáneo.
Future<InsertResult> registrarManualSmart({
  required String rut,
  required String tipo,
  int? cupoId,                 // ⬅️ nuevo
}) async {
  await _ensureConnection();

  final existente = await _fetchAtencionALC(rut, tipo);
  if (existente != null) {
    final ok = await _touchALC(existente.id);
    final tk = _bestTicketFromAtencion(existente);
    return InsertResult(
      success: ok,
      ticket: tk,
      message: ok ? 'Atención confirmada (existente), imprimiendo' : 'No se pudo confirmar',
      extra: {
        'id': existente.id,
        'fecha': existente.fecha,
        'tipo': existente.tipo,
        'numRut': existente.numRut,
        'nombres': existente.nombres ?? '',
        'apellidos': existente.apellidos ?? '',
        'numSol': existente.numSol ?? '',
        'correlativo': existente.correlativo,
        'correlativo1': existente.correlativo1 ?? '',
        'consumioCupo': false,         // ⬅️ reimpresión: no consume
        'cupoId': cupoId,
      },
    );
  }

  // No existe → crear correlativo del día
  final ins = await insertarManualEspontaneo(rut: rut, tipo: tipo);
  if (!ins.success) return ins;

  bool consumido = true;
  if (cupoId != null) {
    consumido = await _consumirCupoManual(cupoId); // ⬅️ suma cupo (1..cantidad)
  }

  return InsertResult(
    success: ins.success,
    ticket: ins.ticket,
    message: consumido ? 'Atención registrada' : 'Atención registrada (no se pudo consumir cupo)',
    extra: {
      ...?ins.extra,
      'consumioCupo': consumido,
      'cupoId': cupoId,
    },
  );
}

  Future<bool> _consumirCupoManual(int cupoId) async {
  await _ensureConnection();

  final sql = """
SET NOCOUNT ON;

UPDATE ALCBotonesTotem WITH (ROWLOCK, UPDLOCK)
   SET cuposUsados = ISNULL(cuposUsados, 0) + 1
 WHERE id = $cupoId
   AND ISNULL(activo,0) = 1
   AND CONVERT(time, GETDATE()) BETWEEN horaInicio AND horaTermino
   AND ISNULL(cuposUsados,0) < cantidad;

SELECT ok = CASE WHEN @@ROWCOUNT > 0 THEN 1 ELSE 0 END;
""";

  final rows = List<Map<String, dynamic>>.from(jsonDecode(await _conn.getData(sql)));
  return rows.isNotEmpty && ((rows.first['ok'] as num?)?.toInt() == 1);
}

// Convierte a latin1 "seguro" y quita caracteres problemáticos para VARCHAR
String _toVarcharSafe(String s) {
  // 1) intenta codificar en latin1 (ISO-8859-1)
  var ansi = String.fromCharCodes(latin1.encode(s));

  // 2) reemplazos típicos que terminan en '?'
  ansi = ansi
      .replaceAll('º', 'o')   // Nº -> No / Nro (lo ajustamos abajo)
      .replaceAll('°', 'o')
      .replaceAll('–', '-')   // en dash
      .replaceAll('—', '-')   // em dash
      .replaceAll('“', '"')
      .replaceAll('”', '"')
      .replaceAll('’', "'")
      .replaceAll('´', "'");

  // 3) fallback: si aún queda "?" por caracteres fuera de latin1, desacentuamos
  if (ansi.contains('?')) {
    const from = 'áÁéÉíÍóÓúÚñÑüÜ';
    const to   = 'aAeEiIoOuUnNuU';
    final b = StringBuffer();
    for (final ch in ansi.split('')) {
      final i = from.indexOf(ch);
      b.write(i >= 0 ? to[i] : ch);
    }
    ansi = b.toString();
  }

  // 4) escapar comillas simples para SQL
  return ansi.replaceAll("'", "''");
}

// === Agregar al final de DatabaseService ===============================

// Devuelve la lista de etapas (880..889) para el último estado del RUT.
// Si no existe práctico para el rut, retorna [].
Future<List<Map<String, dynamic>>> etapasPorRut(String rut) async {
  await _ensureConnection();
  final res = await _fetchEstadoPractico(rut); // usa tu método privado
  if (res == null) return [];
  return _fetchEtapas(res.estadoId);           // usa tu método privado
}

// Emite ticket de práctico (correlativo del día 'Z') y devuelve InsertResult.
// Útil para el flujo operador.
Future<InsertResult> emitirTicketPractico({
  required String rut,
  String nombre = '',
  String apellidos = '',
}) async {
  return await insertarAtencionTipoDia(
    rut: rut,
    tipo: 'Z',
    nombres: nombre,
    apellidos: apellidos,
  );
}


}
